<?php
require 'config/db.php';
require 'includes/flash.php';

/* ===== 1. LẤY ID ===== */
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    die('ID không hợp lệ');
}

/* ===== 2. LẤY DỮ LIỆU HIỆN TẠI ===== */
$stmt = $pdo->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->execute([$id]);
$employee = $stmt->fetch();

if (!$employee) {
    die('Nhân viên không tồn tại');
}

/* ===== 3. KHỞI TẠO ===== */
$errors = [];
$data = [
    'full_name' => $employee['full_name'],
    'email'     => $employee['email'],
    'phone'     => $employee['phone'],
    'position'  => $employee['position'],
    'salary'    => $employee['salary'],
    'status'    => $employee['status']
];

/* ===== 4. XỬ LÝ POST ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    foreach ($data as $key => $value) {
        $data[$key] = trim($_POST[$key] ?? '');
    }

    /* ==== VALIDATE ==== */

    // Họ tên
    if ($data['full_name'] === '' || mb_strlen($data['full_name']) < 3) {
        $errors['full_name'] = 'Họ tên phải từ 3–120 ký tự';
    }

    // Email
    if ($data['email'] === '' || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Email không hợp lệ';
    } else {
        // Check unique (trừ chính nó)
        $stmt = $pdo->prepare(
            "SELECT id FROM employees WHERE email = ? AND id != ?"
        );
        $stmt->execute([$data['email'], $id]);
        if ($stmt->fetch()) {
            $errors['email'] = 'Email đã tồn tại';
        }
    }

    // Vị trí
    if ($data['position'] === '') {
        $errors['position'] = 'Vị trí là bắt buộc';
    }

    // Lương
    if ($data['salary'] !== '' && (!is_numeric($data['salary']) || $data['salary'] < 0)) {
        $errors['salary'] = 'Lương phải là số >= 0';
    }

    // Status
    if (!in_array($data['status'], ['0', '1'], true)) {
        $errors['status'] = 'Trạng thái không hợp lệ';
    }

    /* ==== UPDATE ==== */
    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "UPDATE employees
             SET full_name = ?, email = ?, phone = ?, position = ?, salary = ?, status = ?
             WHERE id = ?"
        );
        $stmt->execute([
            $data['full_name'],
            $data['email'],
            $data['phone'],
            $data['position'],
            $data['salary'],
            $data['status'],
            $id
        ]);

        set_flash('Cập nhật nhân viên thành công');
        header('Location: index.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sửa nhân viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

<h3>Sửa nhân viên</h3>

<form method="post">

    <div class="mb-3">
        <label>Họ tên *</label>
        <input type="text" name="full_name" class="form-control"
               value="<?= htmlspecialchars($data['full_name']) ?>">
        <small class="text-danger"><?= $errors['full_name'] ?? '' ?></small>
    </div>

    <div class="mb-3">
        <label>Email *</label>
        <input type="text" name="email" class="form-control"
               value="<?= htmlspecialchars($data['email']) ?>">
        <small class="text-danger"><?= $errors['email'] ?? '' ?></small>
    </div>

    <div class="mb-3">
        <label>Điện thoại</label>
        <input type="text" name="phone" class="form-control"
               value="<?= htmlspecialchars($data['phone']) ?>">
    </div>

    <div class="mb-3">
        <label>Vị trí *</label>
        <input type="text" name="position" class="form-control"
               value="<?= htmlspecialchars($data['position']) ?>">
        <small class="text-danger"><?= $errors['position'] ?? '' ?></small>
    </div>

    <div class="mb-3">
        <label>Lương</label>
        <input type="number" name="salary" class="form-control"
               value="<?= htmlspecialchars($data['salary']) ?>">
        <small class="text-danger"><?= $errors['salary'] ?? '' ?></small>
    </div>

    <div class="mb-3">
        <label>Trạng thái</label>
        <select name="status" class="form-control">
            <option value="1" <?= $data['status'] == 1 ? 'selected' : '' ?>>Active</option>
            <option value="0" <?= $data['status'] == 0 ? 'selected' : '' ?>>Inactive</option>
        </select>
        <small class="text-danger"><?= $errors['status'] ?? '' ?></small>
    </div>

    <button class="btn btn-primary">Update</button>
    <a href="index.php" class="btn btn-secondary">Back</a>

</form>

</body>
</html>
