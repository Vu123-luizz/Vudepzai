<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function set_flash($msg, $type = 'success')
{
    $_SESSION['flash'] = [
        'msg' => $msg,
        'type' => $type
    ];
}

function get_flash()
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);

        return '<div class="alert alert-' . $flash['type'] . '">' .
               htmlspecialchars($flash['msg']) .
               '</div>';
    }
    return '';
}
