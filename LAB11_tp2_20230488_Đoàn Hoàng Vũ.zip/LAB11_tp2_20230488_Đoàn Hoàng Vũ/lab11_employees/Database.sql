CREATE DATABASE IF NOT EXISTS lab11_employees
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE lab11_employees;
CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    position VARCHAR(100),
    salary INT,
    status TINYINT DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
INSERT INTO employees (full_name, email, phone, position, salary, status) VALUES
('Nguyễn Văn A', 'a@gmail.com', '0901234567', 'Bán hàng', 8000000, 1),
('Trần Thị B', 'b@gmail.com', NULL, 'Kế toán', 9000000, 1),
('Lê Văn C', 'c@gmail.com', NULL, 'Kho', 7000000, 1),
('Phạm Thị D', 'd@gmail.com', '0855409152', 'Nhân sự', 8500000, 1),
('Tuấn', 'tuanchu090@gmail.com', '0855409152', 'Sếp', 1, 1),
('Đoàn Hoàng Vũ', 'vu@gmail.com', '123213213', 'Đệ sếp', 2000, 1);
