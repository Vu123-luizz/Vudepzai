<?php
require_once __DIR__ . '/config/db.php';

$data = [
    'full_name' => '',
    'email' => '',
    'phone' => '',
    'position' => '',
    'salary' => '',
    'status' => 1
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [
        'full_name' => trim($_POST['full_name']),
        'email'     => trim($_POST['email']),
        'phone'     => trim($_POST['phone']),
        'position'  => trim($_POST['position']),
        'salary'    => $_POST['salary'] ?: null,
        'status'    => $_POST['status']
    ];

    $sql = "INSERT INTO employees
            (full_name, email, phone, position, salary, status, created_at)
            VALUES (:full_name, :email, :phone, :position, :salary, :status, NOW())";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($data);

    header('Location: index.php');
    exit;
}
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <title>Thêm nhân viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">➕ Thêm nhân viên</h5>
                </div>
                <div class="card-body">
                    <form method="post">

                        <div class="mb-3">
                            <label class="form-label">Họ tên *</label>
                            <input class="form-control" name="full_name" required
                                   value="<?= htmlspecialchars($data['full_name']) ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email *</label>
                            <input class="form-control" type="email" name="email" required
                                   value="<?= htmlspecialchars($data['email']) ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Điện thoại</label>
                            <input class="form-control" name="phone"
                                   value="<?= htmlspecialchars($data['phone']) ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Vị trí *</label>
                            <input class="form-control" name="position" required
                                   value="<?= htmlspecialchars($data['position']) ?>">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Lương</label>
                            <input class="form-control" type="number" name="salary"
                                   value="<?= htmlspecialchars($data['salary']) ?>">
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Trạng thái</label>
                            <select class="form-select" name="status">
                                <option value="1" <?= $data['status']==1?'selected':'' ?>>Active</option>
                                <option value="0" <?= $data['status']==0?'selected':'' ?>>Inactive</option>
                            </select>
                        </div>

                        <div class="d-flex justify-content-between">
                            <a href="index.php" class="btn btn-secondary">⬅ Back</a>
                            <button class="btn btn-success px-4">💾 Save</button>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body>
</html>
