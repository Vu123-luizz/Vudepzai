<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/flash.php';

$keyword = trim($_GET['keyword'] ?? '');

if ($keyword === '') {
    $stmt = $pdo->query("SELECT * FROM employees ORDER BY id DESC");
} else {
    $stmt = $pdo->prepare("
        SELECT * FROM employees
        WHERE full_name LIKE :kw1
           OR email LIKE :kw2
        ORDER BY id DESC
    ");
    $stmt->execute([
        ':kw1' => '%' . $keyword . '%',
        ':kw2' => '%' . $keyword . '%'
    ]);
}

$employees = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý nhân viên</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">

    <h3 class="mb-3">Danh sách nhân viên</h3>

    <?php if ($msg = get_flash('success')): ?>
        <div class="alert alert-success">
            <?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <?php if ($msg = get_flash('error')): ?>
        <div class="alert alert-danger">
            <?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?>
        </div>
    <?php endif; ?>

    <div class="row mb-3">
        <div class="col-md-8">
            <form method="get" class="d-flex">
                <input type="text"
                       name="keyword"
                       class="form-control me-2"
                       placeholder="Tìm theo tên hoặc email"
                       value="<?= htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') ?>">
                <button class="btn btn-primary">Search</button>
            </form>
        </div>
        <div class="col-md-4 text-end">
            <a href="create.php" class="btn btn-success">+ Thêm mới</a>
        </div>
    </div>

    <table class="table table-bordered table-hover align-middle">
        <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Họ tên</th>
            <th>Email</th>
            <th>Điện thoại</th>
            <th>Chức vụ</th>
            <th>Lương</th>
            <th>Trạng thái</th>
            <th>Ngày tạo</th>
            <th>Ngày cập nhật</th>
            <th width="120">Hành động</th>
        </tr>
        </thead>
        <tbody>

        <?php if (empty($employees)): ?>
            <tr>
                <td colspan="10" class="text-center">Không có dữ liệu</td>
            </tr>
        <?php endif; ?>

        <?php foreach ($employees as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['id']) ?></td>
                <td><?= htmlspecialchars($row['full_name']) ?></td>
                <td><?= htmlspecialchars($row['email']) ?></td>
                <td><?= htmlspecialchars($row['phone'] ?? '-') ?></td>
                <td><?= htmlspecialchars($row['position']) ?></td>
                <td><?= $row['salary'] !== null ? number_format($row['salary']) : '-' ?></td>
                <td>
                    <?= $row['status'] == 1
                        ? '<span class="badge bg-success">Active</span>'
                        : '<span class="badge bg-secondary">Inactive</span>' ?>
                </td>
                <td><?= htmlspecialchars($row['created_at']) ?></td>
                <td><?= htmlspecialchars($row['updated_at'] ?? '-') ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="delete.php?id=<?= $row['id'] ?>"
                       class="btn btn-sm btn-danger"
                       onclick="return confirm('Bạn có chắc chắn muốn xóa?')">
                        Delete
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>

</div>
</body>
</html>
