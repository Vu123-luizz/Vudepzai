HƯỚNG DẪN CHẠY PROJECT LAB 11

1. Yêu cầu
- XAMPP (Apache + MySQL)
- PHP = 7.4

2. Cài đặt
- Copy thư mục lab11_employees vào
  Cxampphtdocs

3. Tạo Database
- Mở phpMyAdmin
- Import file database.sql

4. Cấu hình DB
- Mở file configdb.php
- Chỉnh lại
  $host = 'localhost';
  $dbname = 'lab11_employees';
  $user = 'root';
  $pass = '';

5. Chạy project
- Truy cập
  httplocalhostlab11_employeesindex.php
