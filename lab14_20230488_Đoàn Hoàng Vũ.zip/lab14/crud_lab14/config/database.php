<?php
return [
    'host' => 'localhost',
    'dbname' => 'lab14_db',
    'user' => 'root',
    'pass' => '',
];
