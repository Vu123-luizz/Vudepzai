<?php
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../core/Flash.php';

class ProductController {
    private Product $product;
    private string $baseUrl;

    public function __construct(string $baseUrl = '/lab14/crud_lab14/') {
        $this->product = new Product();
        $this->baseUrl = $baseUrl;
    }

    /* ===== LIST + PAGINATION ===== */
    public function index() {
        $perPage = 5;
        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $offset = ($page - 1) * $perPage;

        $total = $this->product->countAll();
        $totalPages = (int) ceil($total / $perPage);

        $products = $this->product->getPaginate($perPage, $offset);

        // Flash message
        $flash = [
            'success' => Flash::get('success'),
            'error'   => Flash::get('error')
        ];

        // biến cho view
        $baseUrl = $this->baseUrl;

        require __DIR__ . '/../../views/products/index.php';
    }

    /* ===== FORM ADD ===== */
    public function create() {
        $baseUrl = $this->baseUrl;
        require __DIR__ . '/../../views/products/create.php';
    }

    /* ===== STORE (UPLOAD + PRG) ===== */
    public function store() {
        try {
            $imagePath = null;

            if (!empty($_FILES['image']['name'])) {
                $imagePath = $this->uploadImage($_FILES['image']);
            }

            $this->product->create([
                'name'  => trim($_POST['name']),
                'price' => (float) $_POST['price'],
                'image' => $imagePath
            ]);

            Flash::set('success', 'Thêm sản phẩm thành công');
        } catch (Exception $e) {
            Flash::set('error', $e->getMessage());
        }

        // PRG pattern – quay về list
        header("Location: ./");
        exit;
    }

    /* ===== UPLOAD ẢNH AN TOÀN ===== */
    private function uploadImage(array $file): string {
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new Exception('Upload file lỗi');
        }

        $allowExt = ['jpg','jpeg','png','webp'];
        $maxSize  = 2 * 1024 * 1024;

        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $allowExt)) {
            throw new Exception('Chỉ cho phép JPG, PNG, WEBP');
        }

        if ($file['size'] > $maxSize) {
            throw new Exception('File tối đa 2MB');
        }

        $mime = mime_content_type($file['tmp_name']);
        if (!str_starts_with($mime, 'image/')) {
            throw new Exception('File không phải ảnh');
        }

        $newName = uniqid('prd_', true) . '.' . $ext;
        $relativePath = 'uploads/products/' . $newName;
        $targetPath   = __DIR__ . '/../../public/' . $relativePath;

        if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
            throw new Exception('Không thể lưu ảnh');
        }

        return $relativePath;
    }
}
