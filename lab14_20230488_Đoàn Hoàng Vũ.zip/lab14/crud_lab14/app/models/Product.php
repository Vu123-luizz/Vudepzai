<?php
require_once __DIR__ . '/../core/Database.php';

class Product {
    private $pdo;

    public function __construct() {
        $this->pdo = Database::connect();
    }

    public function countAll() {
        return $this->pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
    }

    public function getPaginate($limit, $offset) {
        $stmt = $this->pdo->prepare(
            "SELECT * FROM products ORDER BY id DESC LIMIT :offset, :limit"
        );
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function create($data) {
        $stmt = $this->pdo->prepare(
            "INSERT INTO products(name, price, image) VALUES (?, ?, ?)"
        );
        return $stmt->execute([
            $data['name'],
            $data['price'],
            $data['image']
        ]);
    }
}
