<?php

class Database {
    public static function connect() {
        try {
            return new PDO(
                "mysql:host=127.0.0.1;port=3307;dbname=crud_lab14;charset=utf8mb4",
                "root",
                "",
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
                ]
            );
        } catch (PDOException $e) {
            die("❌ Không kết nối được DB: " . $e->getMessage());
        }
    }
}
