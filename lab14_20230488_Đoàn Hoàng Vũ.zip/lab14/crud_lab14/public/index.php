<?php
session_start();

require_once __DIR__ . '/../app/core/Flash.php';
require_once __DIR__ . '/../app/controllers/ProductController.php';

// Base URL
$baseUrl = '/lab14/crud_lab14/public';

$controller = new ProductController($baseUrl);
$action = $_GET['action'] ?? 'index';
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>LAB 14 – Product Management</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #f6f8ff, #eef1f9);
            min-height: 100vh;
        }

        /* NAVBAR */
        .navbar {
            background: linear-gradient(90deg, #4e54c8, #8f94fb);
            box-shadow: 0 8px 25px rgba(0,0,0,.15);
        }
        .navbar-brand {
            font-weight: 600;
            font-size: 20px;
        }

        /* MAIN CARD */
        .main-card {
            background: #fff;
            border-radius: 18px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.08);
            animation: fadeUp .4s ease;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(20px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        /* BUTTON */
        .btn-gradient {
            background: linear-gradient(90deg, #43cea2, #185a9d);
            border: none;
            color: #fff;
            border-radius: 30px;
            padding: 10px 22px;
        }
        .btn-gradient:hover {
            opacity: .9;
            color: #fff;
        }

        /* FOOTER */
        footer {
            color: #777;
            font-size: 14px;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container">
        <a class="navbar-brand" href="<?= $baseUrl ?>/">
            <i class="bi bi-box-seam-fill"></i> Product Manager
        </a>

        <div class="ms-auto">
            <a href="<?= $baseUrl ?>/?action=create" class="btn btn-gradient">
                <i class="bi bi-plus-circle"></i> Thêm sản phẩm
            </a>
        </div>
    </div>
</nav>

<!-- MAIN -->
<div class="container my-5">
    <div class="main-card">

        <?php
        switch ($action) {
            case 'create':
                $controller->create();
                break;

            case 'store':
                $controller->store();
                break;

            default:
                $controller->index();
        }
        ?>

    </div>
</div>

<!-- FOOTER -->
<footer class="text-center pb-4">
    © <?= date('Y') ?> – LAB 14 | PHP MVC CRUD  
    <br>
    <small class="text-muted">
        Bootstrap 5 • Upload Image • Pagination • PDO
    </small>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
