<h3 class="mb-4 fw-semibold">
    <i class="bi bi-list-ul"></i> Danh sách sản phẩm
</h3>

<?php if (!empty($flash['success'])): ?>
    <div class="alert alert-success alert-dismissible fade show">
        <i class="bi bi-check-circle-fill"></i>
        <?= htmlspecialchars($flash['success']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<a href="?action=create" class="btn btn-primary mb-3">
    <i class="bi bi-plus-circle"></i> Thêm mới
</a>

<div class="table-responsive">
    <table class="table table-hover align-middle shadow-sm rounded">
        <thead class="table-dark">
            <tr>
                <th width="60">ID</th>
                <th>Tên sản phẩm</th>
                <th width="140">Giá</th>
                <th width="160" class="text-center">Ảnh</th>
            </tr>
        </thead>

        <tbody>
        <?php foreach ($products as $p): ?>
            <tr>
                <td class="fw-semibold text-muted">
                    #<?= $p['id'] ?>
                </td>

                <td>
                    <div class="fw-semibold">
                        <?= htmlspecialchars($p['name']) ?>
                    </div>
                </td>

                <td class="text-success fw-semibold">
                    <?= number_format($p['price']) ?> đ
                </td>

                <td class="text-center">
                    <?php if (!empty($p['image'])): ?>
                        <img
                            src="/lab14/crud_lab14/public/<?= htmlspecialchars($p['image']) ?>"
                            class="rounded shadow"
                            style="width:90px;height:65px;object-fit:cover"
                        >
                    <?php else: ?>
                        <span class="text-muted fst-italic">Không có ảnh</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- PAGINATION -->
<?php if ($totalPages > 1): ?>
<nav>
    <ul class="pagination justify-content-center mt-4">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <li class="page-item <?= ($i == ($_GET['page'] ?? 1)) ? 'active' : '' ?>">
                <a class="page-link" href="?page=<?= $i ?>">
                    <?= $i ?>
                </a>
            </li>
        <?php endfor; ?>
    </ul>
</nav>
<?php endif; ?>
