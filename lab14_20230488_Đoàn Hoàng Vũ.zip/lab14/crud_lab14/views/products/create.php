<h3 class="mb-4 fw-semibold">
    <i class="bi bi-plus-square-fill"></i> Thêm sản phẩm mới
</h3>

<form method="POST"
      action="?action=store"
      enctype="multipart/form-data"
      class="needs-validation"
      novalidate>

    <!-- TÊN -->
    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-tag-fill"></i> Tên sản phẩm
        </label>
        <input
            type="text"
            name="name"
            class="form-control form-control-lg"
            placeholder="Nhập tên sản phẩm"
            required
        >
        <div class="invalid-feedback">
            Vui lòng nhập tên sản phẩm
        </div>
    </div>

    <!-- GIÁ -->
    <div class="mb-3">
        <label class="form-label fw-semibold">
            <i class="bi bi-cash-stack"></i> Giá sản phẩm
        </label>
        <input
            type="number"
            name="price"
            class="form-control form-control-lg"
            placeholder="Ví dụ: 150000"
            min="0"
            required
        >
        <div class="invalid-feedback">
            Vui lòng nhập giá hợp lệ
        </div>
    </div>

    <!-- ẢNH -->
    <div class="mb-4">
        <label class="form-label fw-semibold">
            <i class="bi bi-image-fill"></i> Ảnh sản phẩm
        </label>
        <input
            type="file"
            name="image"
            class="form-control"
            accept=".jpg,.jpeg,.png,.webp"
        >
        <small class="text-muted">
            Hỗ trợ JPG, PNG, WEBP (tối đa ~2MB)
        </small>
    </div>

    <!-- BUTTON -->
    <div class="d-flex gap-2">
        <button type="submit" class="btn btn-success px-4">
            <i class="bi bi-check-circle"></i> Lưu sản phẩm
        </button>

        <a href="<?= $baseUrl ?>/" class="btn btn-outline-secondary px-4">
            <i class="bi bi-arrow-left"></i> Quay lại
        </a>
    </div>
</form>

<!-- VALIDATION -->
<script>
(() => {
  'use strict'
  const forms = document.querySelectorAll('.needs-validation')
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })
})()
</script>
