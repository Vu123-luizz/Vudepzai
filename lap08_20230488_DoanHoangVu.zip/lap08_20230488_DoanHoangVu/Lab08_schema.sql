1. Tạo CSDL, bảng, constraint và dữ liệu mẫu
-- =========================
-- Lab08_schema.sql
-- =========================

DROP DATABASE IF EXISTS ql_thu_vien;
CREATE DATABASE ql_thu_vien
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE ql_thu_vien;

-- =========================
-- TABLE: categories
-- =========================
CREATE TABLE categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- =========================
-- TABLE: publishers
-- =========================
CREATE TABLE publishers (
    publisher_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL UNIQUE
) ENGINE=InnoDB;

-- =========================
-- TABLE: books
-- =========================
CREATE TABLE books (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    category_id INT NOT NULL,
    publisher_id INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    published_year INT,
    stock INT NOT NULL,
    CONSTRAINT fk_books_category
        FOREIGN KEY (category_id)
        REFERENCES categories(category_id)
        ON DELETE RESTRICT,
    CONSTRAINT fk_books_publisher
        FOREIGN KEY (publisher_id)
        REFERENCES publishers(publisher_id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_books_price CHECK (price > 0),
    CONSTRAINT chk_books_stock CHECK (stock >= 0)
) ENGINE=InnoDB;

-- =========================
-- TABLE: members
-- =========================
CREATE TABLE members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================
-- TABLE: loans
-- =========================
CREATE TABLE loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    member_id INT NOT NULL,
    loan_date DATE NOT NULL,
    due_date DATE NOT NULL,
    status ENUM('BORROWED','RETURNED','OVERDUE') NOT NULL,
    CONSTRAINT fk_loans_member
        FOREIGN KEY (member_id)
        REFERENCES members(member_id)
        ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =========================
-- TABLE: loan_items
-- =========================
CREATE TABLE loan_items (
    loan_id INT NOT NULL,
    book_id INT NOT NULL,
    qty INT NOT NULL,
    PRIMARY KEY (loan_id, book_id),
    CONSTRAINT fk_li_loan
        FOREIGN KEY (loan_id)
        REFERENCES loans(loan_id)
        ON DELETE CASCADE,
    CONSTRAINT fk_li_book
        FOREIGN KEY (book_id)
        REFERENCES books(book_id)
        ON DELETE RESTRICT,
    CONSTRAINT chk_li_qty CHECK (qty > 0)
) ENGINE=InnoDB;

-- =========================
-- DATA SAMPLE
-- =========================

INSERT INTO categories(name) VALUES
('CNTT'),('Kinh tế'),('Thiếu nhi'),('Văn học'),('Khoa học');

INSERT INTO publishers(name) VALUES
('NXB Trẻ'),('NXB Giáo Dục'),('NXB Lao Động');

INSERT INTO books(title, category_id, publisher_id, price, published_year, stock) VALUES
('Lập trình C',1,2,75000,2020,10),
('Lập trình Java',1,2,95000,2021,8),
('Kinh tế vi mô',2,2,88000,2019,6),
('Dế mèn phiêu lưu ký',3,1,45000,2018,12),
('Harry Potter',3,1,120000,2022,7),
('Văn học Việt Nam',4,1,67000,2017,5),
('Vật lý đại cương',5,2,99000,2020,4),
('Hóa học cơ bản',5,2,91000,2021,6),
('SQL căn bản',1,3,85000,2022,9),
('Python nâng cao',1,3,115000,2023,5),
('Marketing 101',2,3,78000,2019,6),
('Tài chính doanh nghiệp',2,3,102000,2020,4),
('Toán thiếu nhi',3,2,39000,2021,15),
('Truyện ngắn hiện đại',4,1,56000,2018,8),
('Thiên văn học',5,3,125000,2022,3);

INSERT INTO members(full_name, phone) VALUES
('Nguyễn Văn A','0901111111'),
('Trần Thị B','0902222222'),
('Lê Văn C','0903333333'),
('Phạm Thị D','0904444444'),
('Hoàng Văn E','0905555555'),
('Vũ Thị F','0906666666'),
('Đỗ Văn G','0907777777'),
('Bùi Thị H','0908888888');

INSERT INTO loans(member_id, loan_date, due_date, status) VALUES
(1,'2025-12-01','2025-12-10','RETURNED'),
(2,'2025-12-05','2025-12-15','BORROWED'),
(3,'2025-12-10','2025-12-20','BORROWED'),
(4,'2025-12-12','2025-12-22','OVERDUE'),
(5,'2025-12-15','2025-12-25','RETURNED'),
(1,'2025-12-20','2025-12-30','BORROWED'),
(2,'2025-12-22','2026-01-01','BORROWED'),
(3,'2025-12-25','2026-01-05','BORROWED'),
(6,'2025-12-28','2026-01-07','BORROWED'),
(7,'2025-12-30','2026-01-09','BORROWED'),
(8,'2026-01-02','2026-01-12','BORROWED'),
(4,'2026-01-05','2026-01-15','BORROWED');

INSERT INTO loan_items VALUES
(1,1,1),(1,2,1),
(2,3,2),(2,4,1),
(3,5,1),(3,6,1),
(4,7,1),(4,8,1),
(5,9,2),
(6,10,1),(6,11,1),
(7,12,1),(7,13,2),
(8,14,1),
(9,15,1),(9,1,1),
(10,2,1),(10,3,1),
(11,4,2),
(12,5,1),(12,6,1);

2. Thao tác vi phạm constraint (chạy để chụp lỗi)
-- Phone trùng
INSERT INTO members(full_name, phone)
VALUES ('Test Phone','0901111111');

-- Stock âm
INSERT INTO books(title, category_id, publisher_id, price, published_year, stock)
VALUES ('Sách lỗi',1,1,50000,2024,-5);

-- Qty = 0
INSERT INTO loan_items(loan_id, book_id, qty)
VALUES (1,3,0);

3. Kiểm tra ON DELETE
DELETE FROM members WHERE member_id = 1;


Giải thích ngắn:
Không xóa được vì loans.member_id dùng ON DELETE RESTRICT, đảm bảo không mất dữ liệu lịch sử mượn sách. Trong khi đó loan_items sẽ tự động bị xóa khi xóa loans nhờ ON DELETE CASCADE.
