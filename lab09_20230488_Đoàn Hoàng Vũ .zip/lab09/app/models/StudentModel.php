<?php
require_once __DIR__ . '/../core/Database.php';

class StudentModel
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function all(): array
    {
        return $this->db
            ->query("SELECT * FROM students ORDER BY id DESC")
            ->fetchAll();
    }

    public function emailExists(string $email): bool
    {
        $stmt = $this->db->prepare(
            "SELECT 1 FROM students WHERE email = ? LIMIT 1"
        );
        $stmt->execute([$email]);
        return (bool)$stmt->fetchColumn();
    }

    public function create(array $data): bool|string
    {
        if ($this->emailExists($data['email'])) {
            return 'EMAIL_EXISTS';
        }

        $stmt = $this->db->prepare(
            "INSERT INTO students(code, full_name, email, dob)
             VALUES (:code, :full_name, :email, :dob)"
        );

        return $stmt->execute($data);
    }

    public function delete(int $id): bool
    {
        return $this->db
            ->prepare("DELETE FROM students WHERE id = ?")
            ->execute([$id]);
    }
}
