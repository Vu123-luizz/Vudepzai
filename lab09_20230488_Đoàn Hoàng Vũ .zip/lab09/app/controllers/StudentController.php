<?php
require_once __DIR__ . '/../models/StudentModel.php';

class StudentController
{
    private StudentModel $model;

    public function __construct()
    {
        $this->model = new StudentModel();
    }

    public function index()
    {
        $students = $this->model->all();
        require __DIR__ . '/../views/students/index.php';
    }

    public function store()
    {
        $data = [
            'code'      => trim($_POST['code'] ?? ''),
            'full_name' => trim($_POST['full_name'] ?? ''),
            'email'     => trim($_POST['email'] ?? ''),
            'dob'       => $_POST['dob'] ?: null,
        ];

        if (!$data['code'] || !$data['full_name'] || !$data['email']) {
            header('Location: index.php?c=student&error=empty');
            exit;
        }

        $result = $this->model->create($data);

        if ($result === 'EMAIL_EXISTS') {
            header('Location: index.php?c=student&error=email');
            exit;
        }

        header('Location: index.php?c=student&success=1');
        exit;
    }

    public function delete()
    {
        $id = (int)($_GET['id'] ?? 0);
        if ($id > 0) {
            $this->model->delete($id);
        }
        header('Location: index.php?c=student');
        exit;
    }
}
