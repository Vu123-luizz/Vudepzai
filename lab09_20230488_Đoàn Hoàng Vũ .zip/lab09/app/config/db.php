<?php
return [
    'host' => '127.0.0.1',   // QUAN TRỌNG
    'dbname' => 'it3220_php',
    'user' => 'root',
    'pass' => '',            // XAMPP để trống
    'charset' => 'utf8mb4'
];
