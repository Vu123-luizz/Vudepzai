<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý sinh viên</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-light">

<div class="container mt-5">
<h2 class="text-center mb-4">🎓 Quản lý sinh viên</h2>

<?php if (isset($_GET['success'])): ?>
<div class="alert alert-success">✅ Thêm sinh viên thành công</div>
<?php endif ?>

<?php if (($_GET['error'] ?? '') === 'email'): ?>
<div class="alert alert-danger">❌ Email đã tồn tại</div>
<?php endif ?>

<div class="card p-4 mb-4 bg-secondary">
<form method="post" action="index.php?c=student&a=store">
<div class="row g-3">
    <div class="col-md-3"><input name="code" class="form-control" placeholder="Mã SV" required></div>
    <div class="col-md-3"><input name="full_name" class="form-control" placeholder="Họ tên" required></div>
    <div class="col-md-3"><input name="email" class="form-control" placeholder="Email" required></div>
    <div class="col-md-2"><input type="date" name="dob" class="form-control"></div>
    <div class="col-md-1 d-grid"><button class="btn btn-primary">Lưu</button></div>
</div>
</form>
</div>

<div class="card bg-secondary p-3">
<table class="table table-dark table-hover mb-0">
<thead>
<tr>
<th>#</th><th>Mã</th><th>Tên</th><th>Email</th><th>Ngày sinh</th><th></th>
</tr>
</thead>
<tbody>
<?php if ($students): foreach ($students as $i => $s): ?>
<tr>
<td><?= $i+1 ?></td>
<td><?= htmlspecialchars($s['code']) ?></td>
<td><?= htmlspecialchars($s['full_name']) ?></td>
<td><?= htmlspecialchars($s['email']) ?></td>
<td><?= $s['dob'] ?></td>
<td>
<a href="index.php?c=student&a=delete&id=<?= $s['id'] ?>"
   onclick="return confirm('Xóa sinh viên này?')"
   class="btn btn-danger btn-sm">Xóa</a>
</td>
</tr>
<?php endforeach; else: ?>
<tr><td colspan="6" class="text-center">Chưa có sinh viên</td></tr>
<?php endif ?>
</tbody>
</table>
</div>

</div>
</body>
</html>
