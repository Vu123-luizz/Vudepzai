<?php
require_once __DIR__ . '/../app/core/Database.php';

$pdo = Database::getInstance();
$stmt = $pdo->query("SELECT COUNT(*) FROM students");
echo "Kết nối OK - Số SV: " . $stmt->fetchColumn();
