<?php
require_once '../app/core/Database.php';
require_once '../app/controllers/StudentController.php';

$c = $_GET['c'] ?? 'student';
$a = $_GET['a'] ?? 'index';

$controllerName = ucfirst($c) . 'Controller';

if (!class_exists($controllerName)) {
    die("Controller {$controllerName} không tồn tại");
}

$controller = new $controllerName();

if (!method_exists($controller, $a)) {
    die("Action {$a} không tồn tại");
}

$controller->$a();
