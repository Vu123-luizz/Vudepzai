function loadData(highlightId = null) {
    $.get('index.php?c=student&a=api&action=list', res => {
        let html = '';

        if (!res.data.length) {
            html = `<tr><td colspan="6" class="text-center">Chưa có dữ liệu</td></tr>`;
        } else {
            res.data.forEach((s, i) => {
                html += `
                <tr ${highlightId == s.id ? 'style="background:#0d6efd22"' : ''}>
                    <td>${i + 1}</td>
                    <td>${s.code}</td>
                    <td>${s.full_name}</td>
                    <td>${s.email}</td>
                    <td>${s.dob || ''}</td>
                    <td>
                        <button class="btn btn-warning btn-sm"
                            onclick='edit(${JSON.stringify(s)})'>Sửa</button>
                        <button class="btn btn-danger btn-sm"
                            onclick='del(${s.id})'>Xóa</button>
                    </td>
                </tr>`;
            });
        }
        $('#data').html(html);
    }, 'json');
}

loadData();

$('#formStudent').submit(function (e) {
    e.preventDefault();

    let isUpdate = $('[name=id]').val() !== '';
    let data = $(this).serializeArray();

    data.push({
        name: 'action',
        value: isUpdate ? 'update' : 'create'
    });

    $.post('index.php?c=student&a=api', data, res => {
        if (!res.success) {
            alert(res.message || 'Lỗi!');
            return;
        }

        this.reset();
        $('[name=id]').val('');
        loadData(res.id ?? null);
    }, 'json');
});

function edit(s) {
    for (let k in s) {
        $(`[name=${k}]`).val(s[k]);
    }
}

function del(id) {
    if (!confirm('Xóa sinh viên?')) return;

    $.post(
        'index.php?c=student&a=api',
        { action: 'delete', id },
        () => loadData(),
        'json'
    );
}
