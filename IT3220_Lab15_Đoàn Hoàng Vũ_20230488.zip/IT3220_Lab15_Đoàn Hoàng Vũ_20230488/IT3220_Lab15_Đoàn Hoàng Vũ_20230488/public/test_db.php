<?php
require_once '../core/Database.php';

$db = new Database();
echo "Kết nối phpMyAdmin THÀNH CÔNG";
