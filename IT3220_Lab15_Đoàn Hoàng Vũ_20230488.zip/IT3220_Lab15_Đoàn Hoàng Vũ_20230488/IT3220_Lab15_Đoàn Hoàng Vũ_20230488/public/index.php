<?php
session_start();

require_once __DIR__ . '/../controllers/ProductsController.php';

$controller = new ProductsController();

$action = $_GET['action'] ?? 'index';

if (!method_exists($controller, $action)) {
    die('Action không tồn tại');
}

$controller->$action();
