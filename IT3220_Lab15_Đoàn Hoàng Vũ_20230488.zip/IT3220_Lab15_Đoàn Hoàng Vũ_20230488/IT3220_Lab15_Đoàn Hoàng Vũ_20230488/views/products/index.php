<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Danh sách sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

<h3>Danh sách sản phẩm</h3>

<?php if (!empty($_SESSION['msg'])): ?>
    <div class="alert alert-success">
        <?= $_SESSION['msg']; unset($_SESSION['msg']); ?>
    </div>
<?php endif; ?>

<a href="index.php?action=create" class="btn btn-primary mb-3">+ Thêm sản phẩm</a>

<table class="table table-bordered">
    <tr>
        <th>ID</th><th>Tên</th><th>Giá</th><th>Hành động</th>
    </tr>
    <?php foreach ($products as $p): ?>
    <tr>
        <td><?= $p['id'] ?></td>
        <td><?= $p['name'] ?></td>
        <td><?= number_format($p['price']) ?> đ</td>
        <td>
            <a href="index.php?action=edit&id=<?= $p['id'] ?>" class="btn btn-warning btn-sm">Sửa</a>
            <a href="index.php?action=delete&id=<?= $p['id'] ?>" 
               onclick="return confirm('Xoá?')" 
               class="btn btn-danger btn-sm">Xoá</a>
        </td>
    </tr>
    <?php endforeach; ?>
</table>

<nav>
<?php for ($i = 1; $i <= $totalPages; $i++): ?>
    <a class="btn btn-outline-secondary btn-sm" href="index.php?page=<?= $i ?>">
        <?= $i ?>
    </a>
<?php endfor; ?>
</nav>

</body>
</html>
