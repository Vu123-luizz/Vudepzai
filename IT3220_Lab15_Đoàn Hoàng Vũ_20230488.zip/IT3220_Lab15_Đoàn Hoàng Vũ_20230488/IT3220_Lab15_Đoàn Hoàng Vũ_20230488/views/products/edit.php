<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sửa sản phẩm</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-4">

<h3>Sửa sản phẩm</h3>

<form method="post">
    <div class="mb-3">
        <label>Tên</label>
        <input name="name" class="form-control" value="<?= $product['name'] ?>" required>
    </div>
    <div class="mb-3">
        <label>Giá</label>
        <input name="price" type="number" class="form-control" value="<?= $product['price'] ?>" required>
    </div>
    <button class="btn btn-primary">Cập nhật</button>
    <a href="index.php" class="btn btn-secondary">Quay lại</a>
</form>

</body>
</html>
