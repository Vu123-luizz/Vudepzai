<?php
require_once __DIR__ . '/../core/Database.php';

class Products
{
    private $db;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->conn;
    }

    public function countAll()
    {
        $rs = $this->db->query("SELECT COUNT(*) AS total FROM products");
        return $rs->fetch_assoc()['total'];
    }

    public function getPage($limit, $offset)
    {
        $sql = "SELECT * FROM products LIMIT $limit OFFSET $offset";
        $rs = $this->db->query($sql);

        $data = [];
        while ($row = $rs->fetch_assoc()) {
            $data[] = $row;
        }
        return $data;
    }

    public function find($id)
    {
        $id = (int)$id;
        return $this->db->query("SELECT * FROM products WHERE id=$id")->fetch_assoc();
    }

    public function create($name, $price)
    {
        $name = $this->db->real_escape_string($name);
        $price = (int)$price;
        return $this->db->query(
            "INSERT INTO products(name, price) VALUES ('$name', $price)"
        );
    }

    public function update($id, $name, $price)
    {
        $id = (int)$id;
        $name = $this->db->real_escape_string($name);
        $price = (int)$price;
        return $this->db->query(
            "UPDATE products SET name='$name', price=$price WHERE id=$id"
        );
    }

    public function delete($id)
    {
        $id = (int)$id;
        return $this->db->query("DELETE FROM products WHERE id=$id");
    }
}
