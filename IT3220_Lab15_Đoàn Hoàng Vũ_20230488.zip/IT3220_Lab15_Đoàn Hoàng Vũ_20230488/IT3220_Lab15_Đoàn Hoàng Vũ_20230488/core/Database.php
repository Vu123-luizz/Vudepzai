<?php
class Database
{
    public $conn;

    public function __construct()
    {
        $this->conn = new mysqli(
            'localhost', // host
            'root',      // user (XAMPP mặc định)
            '',          // password (XAMPP mặc định)
            'lap14'      // tên database
        );

        if ($this->conn->connect_error) {
            die('Kết nối CSDL thất bại: ' . $this->conn->connect_error);
        }

        // Set UTF-8
        $this->conn->set_charset("utf8mb4");
    }
}
