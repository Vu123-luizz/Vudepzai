<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../models/Products.php';

class ProductsController
{
    private $products;

    public function __construct()
    {
        $this->products = new Products();
    }

    // Danh sách + phân trang
    public function index()
    {
        $limit = 3;
        $page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $limit;

        $total = $this->products->countAll();
        $products = $this->products->getPage($limit, $offset);
        $totalPages = ceil($total / $limit);

        require __DIR__ . '/../views/products/index.php';
    }

    // Thêm
    public function create()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name  = $_POST['name'] ?? '';
            $price = $_POST['price'] ?? 0;

            $this->products->create($name, $price);
            $_SESSION['msg'] = 'Thêm thành công';

            header('Location: index.php');
            exit;
        }

        require __DIR__ . '/../views/products/create.php';
    }

    // Sửa
    public function edit()
    {
        if (!isset($_GET['id'])) {
            header('Location: index.php');
            exit;
        }

        $id = (int)$_GET['id'];
        $product = $this->products->find($id);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name  = $_POST['name'] ?? '';
            $price = $_POST['price'] ?? 0;

            $this->products->update($id, $name, $price);
            $_SESSION['msg'] = 'Cập nhật thành công';

            header('Location: index.php');
            exit;
        }

        require __DIR__ . '/../views/products/edit.php';
    }

    // Xoá
    public function delete()
    {
        if (isset($_GET['id'])) {
            $id = (int)$_GET['id'];
            $this->products->delete($id);
            $_SESSION['msg'] = 'Xoá thành công';
        }

        header('Location: index.php');
        exit;
    }
}
