<?php
// Trang dashboard
session_start();

// Không cho truy cập nếu chưa đăng nhập
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>

<!-- Hiển thị lời chào -->
<h2>Xin chào <?php echo $_SESSION['user']; ?></h2>

<!-- Nút logout -->
<a href="logout.php">Logout</a>

</body>
</html>
