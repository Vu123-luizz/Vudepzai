<?php
// Xử lý đăng nhập
session_start();

// Tài khoản mẫu
$correct_email = "admin@gmail.com";
$correct_password = "123456";

// Lấy dữ liệu từ form
$email = $_POST['email'];
$password = $_POST['password'];

// Kiểm tra thông tin
if ($email === $correct_email && $password === $correct_password) {
    // Tạo session khi đăng nhập thành công
    $_SESSION['user'] = $email;

    // Chuyển sang dashboard
    header("Location: dashboard.php");
    exit();
} else {
    // Ghi lỗi vào session
    $_SESSION['error'] = "Sai email hoặc mật khẩu";

    // Quay lại trang login
    header("Location: login.php");
    exit();
}
