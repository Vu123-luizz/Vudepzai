Họ và tên: Lương Quang Dũng
lớp :DCCNTT14.1
MSV:20230218


Trang login:
http://localhost/mini_login/login.php
Sau khi đăng nhập đúng → tự chuyển sang:
http://localhost/mini_login/dashboard.php
Logout → tự quay lại:
http://localhost/mini_login/login.php
Nếu gõ trực tiếp:
http://localhost/mini_login/dashboard.php
Tài khoản mẫu để test:
Email: admin@gmail.com
Password: 123456
