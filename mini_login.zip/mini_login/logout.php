<?php
// Đăng xuất
session_start();

// Hủy toàn bộ session
session_destroy();

// Quay về trang login
header("Location: login.php");
exit();

