<?php
return [
    'host'   => '127.0.0.1',
    'port'   => 3307,
    'dbname' => 'mvc_lab12',
    'user'   => 'root',
    'pass'   => ''
];
