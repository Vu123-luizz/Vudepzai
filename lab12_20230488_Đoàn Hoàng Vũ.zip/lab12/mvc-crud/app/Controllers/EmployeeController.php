<?php
require_once __DIR__ . '/../Models/Employee.php';

class EmployeeController {
    private $model;

    public function __construct() {
        $this->model = new Employee();
    }

    // Danh sách + tìm kiếm
    public function index() {
        $q = $_GET['q'] ?? '';
        $employees = $this->model->getAll($q);
        require __DIR__ . '/../Views/employees/index.php';
    }

    // Thêm nhân viên
    public function create() {
        $errors = [];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $full_name = trim($_POST['full_name'] ?? '');
            $phone     = trim($_POST['phone'] ?? '');
            $position  = $_POST['position'] ?? '';
            $salary    = $_POST['salary'] ?? 0;

            if ($full_name === '') {
                $errors[] = 'Họ tên không được rỗng';
            }

            if (!preg_match('/^0\d{9,10}$/', $phone)) {
                $errors[] = 'SĐT không hợp lệ';
            }

            if (empty($errors)) {
                $this->model->insert([
                    $full_name,
                    $phone,
                    $position,
                    $salary
                ]);

                header('Location: index.php?c=employee&a=index');
                exit;
            }
        }

        require __DIR__ . '/../Views/employees/create.php';
    }

    // Sửa
    public function edit() {
        $id = $_GET['id'] ?? null;
        if (!$id) {
            header('Location: index.php?c=employee&a=index');
            exit;
        }

        $employee = $this->model->findById($id);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $this->model->update($id, [
                $_POST['full_name'],
                $_POST['phone'],
                $_POST['position'],
                $_POST['salary']
            ]);

            header('Location: index.php?c=employee&a=index');
            exit;
        }

        require __DIR__ . '/../Views/employees/edit.php';
    }

    // Xóa
    public function delete() {
        $id = $_GET['id'] ?? null;
        if ($id) {
            $this->model->delete($id);
        }
        header('Location: index.php?c=employee&a=index');
        exit;
    }
}
