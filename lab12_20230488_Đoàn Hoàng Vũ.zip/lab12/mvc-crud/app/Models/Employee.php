<?php
require_once __DIR__ . '/../../core/Database.php';

class Employee {
    private $db;

    public function __construct() {
        $this->db = Database::connect();
    }

    // Lấy danh sách + tìm kiếm
    public function getAll($q = '') {
        $sql = "SELECT * FROM employees
                WHERE full_name LIKE :q OR phone LIKE :q
                ORDER BY id DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':q' => "%$q%"
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function findById($id) {
        $stmt = $this->db->prepare("SELECT * FROM employees WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function insert($data) {
        $sql = "INSERT INTO employees (full_name, phone, position, salary)
                VALUES (?, ?, ?, ?)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($data);
    }

    public function update($id, $data) {
        $sql = "UPDATE employees
                SET full_name = ?, phone = ?, position = ?, salary = ?
                WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([...$data, $id]);
    }

    public function delete($id) {
        $stmt = $this->db->prepare("DELETE FROM employees WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
