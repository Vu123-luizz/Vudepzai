<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm nhân viên</title>

    <style>
        * { box-sizing: border-box; }

        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            min-height: 100vh;
            background: linear-gradient(135deg, #43cea2, #185a9d);
            padding: 40px;
        }

        #particles {
            position: fixed;
            inset: 0;
            z-index: -1;
        }

        .container {
            max-width: 500px;
            background: #fff;
            margin: auto;
            padding: 25px 30px;
            border-radius: 14px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.25);
        }

        h2 {
            text-align: center;
            color: #185a9d;
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
            display: block;
            margin-top: 12px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        .actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        button {
            padding: 10px 18px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
        }

        .save {
            background: #43cea2;
            color: #fff;
        }

        .back {
            background: #bdc3c7;
            text-decoration: none;
            color: #333;
            display: flex;
            align-items: center;
            padding: 10px 18px;
            border-radius: 6px;
        }
    </style>
</head>

<body>

<canvas id="particles"></canvas>

<div class="container">
    <h2>Thêm nhân viên</h2>

    <form method="post">
        <label>Họ tên</label>
        <input type="text" name="full_name" required>

        <label>Số điện thoại</label>
        <input type="text" name="phone" required>

        <label>Chức vụ</label>
        <input type="text" name="position">

        <label>Lương</label>
        <input type="number" name="salary">

        <div class="actions">
            <button class="save" type="submit">Lưu</button>
            <a class="back" href="?c=employee&a=index">Quay lại</a>
        </div>
    </form>
</div>

<!-- JS particle -->
<script>
    const canvas = document.getElementById('particles');
    const ctx = canvas.getContext('2d');

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    resize();
    window.onresize = resize;

    const particles = Array.from({ length: 80 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 2 + 1,
        dx: (Math.random() - 0.5) * 0.6,
        dy: (Math.random() - 0.5) * 0.6
    }));

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        particles.forEach(p => {
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(255,255,255,0.8)';
            ctx.fill();
            p.x += p.dx;
            p.y += p.dy;
            if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
            if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
        });
        requestAnimationFrame(animate);
    }
    animate();
</script>

</body>
</html>
