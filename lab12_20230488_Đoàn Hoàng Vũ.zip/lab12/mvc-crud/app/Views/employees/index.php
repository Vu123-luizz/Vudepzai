<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách nhân viên</title>

    <style>
        * { box-sizing: border-box; }

        body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    min-height: 100vh;
    background: radial-gradient(
        circle at top,
        #2b3648,
        #111827 70%
    );
    padding: 40px;
    overflow-x: hidden;
}

        /* ===== Galaxy canvas ===== */
        #particles {
            position: fixed;
            inset: 0;
            z-index: -1;
        }

        .container {
            background: rgba(255,255,255,0.95);
            backdrop-filter: blur(6px);
            max-width: 1100px;
            margin: auto;
            padding: 25px 30px;
            border-radius: 16px;
            box-shadow: 0 20px 45px rgba(0,0,0,0.35);
        }

        h2 {
            margin: 0 0 20px;
            text-align: center;
            color: #185a9d;
        }

        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            gap: 10px;
            flex-wrap: wrap;
        }

        .top-bar form {
            display: flex;
            gap: 8px;
        }

        input[type="text"] {
            padding: 8px 10px;
            width: 230px;
            border-radius: 6px;
            border: 1px solid #ccc;
        }

        button, .btn {
            padding: 8px 14px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }

        button {
            background: #185a9d;
            color: #fff;
        }

        .btn-add {
            background: #43cea2;
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        th {
            background: #185a9d;
            color: white;
            padding: 12px;
        }

        td {
            padding: 10px;
            text-align: center;
        }

        tr:nth-child(even) { background: #f3f6f9; }

        tr:hover { background: #eef3f7; }

        a.action {
            text-decoration: none;
            padding: 6px 10px;
            border-radius: 5px;
            color: white;
            font-size: 13px;
        }

        .edit { background: #f39c12; }
        .delete { background: #e74c3c; }

        .empty {
            text-align: center;
            padding: 20px;
            color: #666;
        }
    </style>
</head>

<body>

<canvas id="particles"></canvas>

<div class="container">
    <h2>Danh sách nhân viên</h2>

    <div class="top-bar">
        <form method="get">
            <input type="hidden" name="c" value="employee">
            <input type="hidden" name="a" value="index">
            <input type="text" name="q"
                   placeholder="Tìm tên hoặc SĐT"
                   value="<?= htmlspecialchars($q ?? '') ?>">
            <button>Tìm</button>
        </form>

        <a class="btn btn-add" href="?c=employee&a=create">+ Thêm nhân viên</a>
    </div>

    <table>
        <tr>
            <th>Họ tên</th>
            <th>SĐT</th>
            <th>Chức vụ</th>
            <th>Lương</th>
            <th>Hành động</th>
        </tr>

        <?php if (empty($employees)): ?>
            <tr><td colspan="5" class="empty">Không có nhân viên</td></tr>
        <?php else: foreach ($employees as $e): ?>
            <tr>
                <td><?= htmlspecialchars($e['full_name']) ?></td>
                <td><?= htmlspecialchars($e['phone']) ?></td>
                <td><?= htmlspecialchars($e['position']) ?></td>
                <td><?= number_format($e['salary']) ?> đ</td>
                <td>
                    <a class="action edit" href="?c=employee&a=edit&id=<?= $e['id'] ?>">Sửa</a>
                    <a class="action delete"
                       onclick="return confirm('Xóa nhân viên này?')"
                       href="?c=employee&a=delete&id=<?= $e['id'] ?>">Xóa</a>
                </td>
            </tr>
        <?php endforeach; endif; ?>
    </table>
</div>

<script>
const canvas = document.getElementById('particles');
const ctx = canvas.getContext('2d');
const SPEED = 1.0; // đổi số này để nhanh/chậm

function resize() {
    canvas.width = innerWidth;
    canvas.height = innerHeight;
}
resize();
addEventListener('resize', resize);

const particles = [];
const COUNT = 350;       // ⬅ NHIỀU HẠT HƠN
const MAX_DIST = 150;
let mouse = { x: null, y: null };

addEventListener('mousemove', e => {
    mouse.x = e.clientX;
    mouse.y = e.clientY;
});
addEventListener('mouseleave', () => {
    mouse.x = null;
    mouse.y = null;
});

for (let i = 0; i < COUNT; i++) {
    particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        r: Math.random() * 5.0 + 2.5,  // ⬅ hạt to vừa
       dx: (Math.random() - 0.5) * SPEED,
       dy: (Math.random() - 0.5) * SPEED
    });
}

function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    particles.forEach((p, i) => {
        // hạt
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.shadowBlur = 12;
        ctx.shadowColor = 'rgba(255,255,255,0.8)';
        ctx.fill();
        ctx.shadowBlur = 0;

        // nối hạt
        for (let j = i + 1; j < particles.length; j++) {
            const p2 = particles[j];
            const d = Math.hypot(p.x - p2.x, p.y - p2.y);
            if (d < MAX_DIST) {
                ctx.strokeStyle = `rgba(180,200,255,${1 - d / MAX_DIST})`;
                ctx.lineWidth = 0.6;
                ctx.beginPath();
                ctx.moveTo(p.x, p.y);
                ctx.lineTo(p2.x, p2.y);
                ctx.stroke();
            }
        }

        // tương tác chuột
        if (mouse.x) {
            const d = Math.hypot(p.x - mouse.x, p.y - mouse.y);
            if (d < 180) {
                p.x += (p.x - mouse.x) * 0.006;
                p.y += (p.y - mouse.y) * 0.006;
            }
        }

        p.x += p.dx * 3.0;
	p.y += p.dy * 3.0;


        if (p.x < 0 || p.x > canvas.width) p.dx *= -1;
        if (p.y < 0 || p.y > canvas.height) p.dy *= -1;
    });

    requestAnimationFrame(draw);
}
draw();
</script>

</body>
</html>
