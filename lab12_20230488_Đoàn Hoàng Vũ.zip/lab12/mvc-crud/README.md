\# LAB 12 – MVC CRUD PHP



\## Cách chạy

1\. Import database.sql vào MySQL

2\. Cấu hình config/database.php

3\. Chép thư mục vào htdocs

4\. Truy cập: http://localhost/lab12/mvc-crud/public/



\## Công nghệ

\- PHP 8.x

\- PDO + Prepared Statement

\- MVC Pattern

