<?php
class Database {
    private static $conn;

    public static function connect() {
        if (!self::$conn) {
            $config = require __DIR__ . '/../config/database.php';

            $dsn = "mysql:host={$config['host']};port={$config['port']};dbname={$config['dbname']};charset=utf8mb4";

            self::$conn = new PDO(
                $dsn,
                $config['user'],
                $config['pass']
            );

            self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        return self::$conn;
    }
}
