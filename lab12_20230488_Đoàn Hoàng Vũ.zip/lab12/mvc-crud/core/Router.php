<?php
class Router {
    public static function dispatch() {
        $controller = $_GET['c'] ?? 'employee';
        $action = $_GET['a'] ?? 'index';

        $controllerName = ucfirst($controller) . 'Controller';
        $file = __DIR__ . "/../app/Controllers/$controllerName.php";

        if (!file_exists($file)) die('Controller not found');

        require $file;
        $obj = new $controllerName();

        if (!method_exists($obj, $action)) die('Action not found');

        $obj->$action();
    }
}
