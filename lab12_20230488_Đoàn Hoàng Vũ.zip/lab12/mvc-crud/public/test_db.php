<?php
try {
    $pdo = new PDO(
        "mysql:host=127.0.0.1;port=3307;dbname=mvc_lab12;charset=utf8mb4",
        "root",
        ""
    );
    echo "MYSQL KẾT NỐI OK";
} catch (PDOException $e) {
    echo $e->getMessage();
}
