<h2>THÊM KHÁCH HÀNG</h2>

<form method="post" action="index.php?c=customers&a=store">
    <p>
        Họ tên:<br>
        <input type="text" name="full_name" required>
    </p>

    <p>
        Email:<br>
        <input type="email" name="email">
    </p>

    <p>
        Điện thoại:<br>
        <input type="text" name="phone">
    </p>

    <button type="submit">Lưu</button>
    <a href="index.php?c=customers&a=index">Hủy</a>
</form>
