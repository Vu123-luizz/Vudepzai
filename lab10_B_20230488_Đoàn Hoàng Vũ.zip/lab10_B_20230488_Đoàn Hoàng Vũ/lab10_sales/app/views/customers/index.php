<h2>DANH SÁCH KHÁCH HÀNG</h2>

<a href="index.php?c=customers&a=create">+ Thêm khách hàng</a>

<table border="1" cellpadding="5">
<tr>
  <th>ID</th>
  <th>Họ tên</th>
  <th>Email</th>
  <th>Điện thoại</th>
</tr>

<?php foreach ($customers as $c): ?>
<tr>
  <td><?= $c['id'] ?></td>
  <td><?= htmlspecialchars($c['full_name']) ?></td>
  <td><?= htmlspecialchars($c['email']) ?></td>
  <td><?= htmlspecialchars($c['phone']) ?></td>
</tr>
<?php endforeach; ?>
</table>
