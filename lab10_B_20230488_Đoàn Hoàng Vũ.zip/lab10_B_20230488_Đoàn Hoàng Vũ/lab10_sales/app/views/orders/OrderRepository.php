<?php
class OrderRepository {
    private $pdo;
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function createOrder($customerId, $items) {
        $this->pdo->beginTransaction();

        try {
            $stmt = $this->pdo->prepare(
                "INSERT INTO orders(customer_id, order_date)
                 VALUES(?, CURDATE())"
            );
            $stmt->execute([$customerId]);
            $orderId = $this->pdo->lastInsertId();

            $total = 0;

            foreach ($items as $item) {
                if ($item['qty'] <= 0) throw new Exception("Qty sai");

                $sql = "INSERT INTO order_items VALUES(?,?,?,?)";
                $stmt = $this->pdo->prepare($sql);
                $stmt->execute([
                    $orderId,
                    $item['product_id'],
                    $item['qty'],
                    $item['price']
                ]);

                $total += $item['qty'] * $item['price'];

                // Trừ tồn kho
                $this->pdo->prepare(
                    "UPDATE products SET stock = stock - ?
                     WHERE id = ? AND stock >= ?"
                )->execute([$item['qty'], $item['product_id'], $item['qty']]);
            }

            $this->pdo->prepare(
                "UPDATE orders SET total=? WHERE id=?"
            )->execute([$total, $orderId]);

            $this->pdo->commit();
            return $orderId;

        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
}
