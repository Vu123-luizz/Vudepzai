<h2>Tạo đơn hàng</h2>

<form method="post" action="index.php?c=orders&a=store">
    <label>Khách hàng:</label>
    <select name="customer_id" required>
        <option value="">-- Chọn --</option>
        <?php foreach ($customers as $c): ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['full_name']) ?></option>
        <?php endforeach ?>
    </select>

    <h3>Sản phẩm</h3>
    <?php foreach ($products as $p): ?>
        <div>
            <?= htmlspecialchars($p['name']) ?> (Tồn: <?= $p['stock'] ?>)
            <input type="number" name="items[<?= $p['id'] ?>]" min="0" value="0">
        </div>
    <?php endforeach ?>

    <button type="submit">Tạo đơn</button>
</form>
