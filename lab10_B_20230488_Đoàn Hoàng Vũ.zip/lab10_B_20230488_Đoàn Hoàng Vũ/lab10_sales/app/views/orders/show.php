<h2>Chi tiết đơn hàng #<?= $order['id'] ?></h2>

<p>Khách hàng: <b><?= htmlspecialchars($order['full_name']) ?></b></p>
<p>Ngày: <?= $order['order_date'] ?></p>

<table border="1">
<tr>
    <th>Sản phẩm</th>
    <th>Số lượng</th>
    <th>Giá</th>
    <th>Thành tiền</th>
</tr>

<?php foreach ($items as $i): ?>
<tr>
    <td><?= htmlspecialchars($i['name']) ?></td>
    <td><?= $i['qty'] ?></td>
    <td><?= number_format($i['price']) ?></td>
    <td><?= number_format($i['qty'] * $i['price']) ?></td>
</tr>
<?php endforeach ?>
</table>

<h3>Tổng cộng: <?= number_format($order['total']) ?></h3>
