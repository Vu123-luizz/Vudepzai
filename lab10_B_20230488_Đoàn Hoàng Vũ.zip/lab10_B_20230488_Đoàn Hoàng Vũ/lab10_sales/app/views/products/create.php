<h2>THÊM SẢN PHẨM</h2>

<form method="post" action="index.php?c=products&a=store">
    <p>
        Tên sản phẩm:<br>
        <input type="text" name="name" required>
    </p>

    <p>
        SKU:<br>
        <input type="text" name="sku">
    </p>

    <p>
        Giá:<br>
        <input type="number" step="0.01" name="price" required>
    </p>

    <p>
        Tồn kho:<br>
        <input type="number" name="stock" value="0">
    </p>

    <button type="submit">Lưu</button>
    <a href="index.php?c=products&a=index">Quay lại</a>
</form>
