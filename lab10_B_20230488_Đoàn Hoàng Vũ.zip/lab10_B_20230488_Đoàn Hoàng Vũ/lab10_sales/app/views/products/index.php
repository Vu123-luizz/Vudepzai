<h2>Danh sách sản phẩm</h2>

<form>
  <input name="search" placeholder="Tìm tên / SKU">
  <button>Tìm</button>
</form>

<a href="index.php?c=products&a=create">+ Thêm</a>

<table border="1">
<tr>
  <th>ID</th><th>Tên</th><th>SKU</th><th>Giá</th><th>Tồn</th>
</tr>
<?php foreach($products as $p): ?>
<tr>
  <td><?= $p['id'] ?></td>
  <td><?= htmlspecialchars($p['name']) ?></td>
  <td><?= $p['sku'] ?></td>
  <td><?= $p['price'] ?></td>
  <td><?= $p['stock'] ?></td>
</tr>
<?php endforeach ?>
</table>
