<?php
require_once __DIR__ . '/../config/db.php';

class OrderRepository
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = db();
    }

    public function all()
    {
        $stmt = $this->pdo->query("
            SELECT o.*, c.full_name
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            ORDER BY o.id DESC
        ");
        return $stmt->fetchAll();
    }

    public function find($id)
    {
        $stmt = $this->pdo->prepare("
            SELECT o.*, c.full_name
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            WHERE o.id = ?
        ");
        $stmt->execute([(int)$id]);
        return $stmt->fetch();
    }

    public function items($orderId)
    {
        $stmt = $this->pdo->prepare("
            SELECT oi.*, p.name
            FROM order_items oi
            JOIN products p ON oi.product_id = p.id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([(int)$orderId]);
        return $stmt->fetchAll();
    }

    public function createOrder($customerId, $items)
    {
        try {
            $this->pdo->beginTransaction();

            // Tạo đơn hàng
            $stmt = $this->pdo->prepare("
                INSERT INTO orders(customer_id, order_date, total)
                VALUES (?, CURDATE(), 0)
            ");
            $stmt->execute([(int)$customerId]);
            $orderId = $this->pdo->lastInsertId();

            $total = 0;

            foreach ($items as $productId => $qty) {
                $qty = (int)$qty;
                if ($qty <= 0) continue;

                // Lấy thông tin sản phẩm
                $stmt = $this->pdo->prepare("
                    SELECT price, stock FROM products WHERE id = ?
                ");
                $stmt->execute([(int)$productId]);
                $product = $stmt->fetch();

                if (!$product || $product['stock'] < $qty) {
                    throw new Exception('Không đủ tồn kho');
                }

                $price = $product['price'];
                $total += $qty * $price;

                // Lưu order_items
                $stmt = $this->pdo->prepare("
                    INSERT INTO order_items(order_id, product_id, qty, price)
                    VALUES (?, ?, ?, ?)
                ");
                $stmt->execute([
                    $orderId,
                    (int)$productId,
                    $qty,
                    $price
                ]);

                // Trừ tồn kho
                $stmt = $this->pdo->prepare("
                    UPDATE products SET stock = stock - ? WHERE id = ?
                ");
                $stmt->execute([$qty, (int)$productId]);
            }

            // Cập nhật tổng tiền
            $stmt = $this->pdo->prepare("
                UPDATE orders SET total = ? WHERE id = ?
            ");
            $stmt->execute([$total, $orderId]);

            $this->pdo->commit();
            return $orderId;

        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
}
