<?php
require_once __DIR__ . '/../config/db.php';

class CustomerRepository
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = db();
    }

    public function all()
    {
        $stmt = $this->pdo->query("SELECT * FROM customers ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public function find($id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM customers WHERE id = ?");
        $stmt->execute([(int)$id]);
        return $stmt->fetch();
    }

    public function create($data)
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO customers(full_name, email, phone)
            VALUES (?, ?, ?)
        ");
        return $stmt->execute([
            $data['full_name'],
            $data['email'],
            $data['phone']
        ]);
    }

    public function update($id, $data)
    {
        $stmt = $this->pdo->prepare("
            UPDATE customers
            SET full_name = ?, email = ?, phone = ?
            WHERE id = ?
        ");
        return $stmt->execute([
            $data['full_name'],
            $data['email'],
            $data['phone'],
            (int)$id
        ]);
    }
}
