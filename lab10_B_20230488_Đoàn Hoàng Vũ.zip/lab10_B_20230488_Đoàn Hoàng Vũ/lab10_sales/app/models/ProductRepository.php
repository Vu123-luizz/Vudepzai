<?php
require_once __DIR__ . '/../config/db.php';

class ProductRepository
{
    private $pdo;

    public function __construct()
    {
        $this->pdo = db();
    }

    public function all()
    {
        $stmt = $this->pdo->query("SELECT * FROM products ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    public function find($id)
    {
        $stmt = $this->pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([(int)$id]);
        return $stmt->fetch();
    }

    public function search($keyword)
    {
        $stmt = $this->pdo->prepare("
            SELECT * FROM products
            WHERE name LIKE ? OR sku LIKE ?
            ORDER BY id DESC
        ");
        $kw = '%' . $keyword . '%';
        $stmt->execute([$kw, $kw]);
        return $stmt->fetchAll();
    }

    public function create($data)
    {
        $stmt = $this->pdo->prepare("
            INSERT INTO products(name, sku, price, stock)
            VALUES (?, ?, ?, ?)
        ");
        return $stmt->execute([
            $data['name'],
            $data['sku'],
            $data['price'],
            $data['stock']
        ]);
    }

    public function update($id, $data)
    {
        $stmt = $this->pdo->prepare("
            UPDATE products
            SET name = ?, sku = ?, price = ?, stock = ?
            WHERE id = ?
        ");
        return $stmt->execute([
            $data['name'],
            $data['sku'],
            $data['price'],
            $data['stock'],
            (int)$id
        ]);
    }

    public function delete($id)
    {
        $stmt = $this->pdo->prepare("DELETE FROM products WHERE id = ?");
        return $stmt->execute([(int)$id]);
    }
}
