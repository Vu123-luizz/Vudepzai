<?php
require_once "../app/models/ProductRepository.php";

class ProductsController {

    public function index() {
        global $pdo;
        $search = $_GET['search'] ?? '';
        $repo = new ProductRepository($pdo);
        $products = $repo->getAll($search);
        require "../app/views/products/index.php";
    }

    public function create() {
        require "../app/views/products/create.php";
    }

    public function store() {
        global $pdo;

        $price = (float)$_POST['price'];
        $stock = (int)$_POST['stock'];

        if ($price < 0 || $stock < 0) die("Dữ liệu không hợp lệ");

        $repo = new ProductRepository($pdo);
        $repo->insert([
            'name'  => $_POST['name'],
            'sku'   => $_POST['sku'],
            'price' => $price,
            'stock' => $stock
        ]);

        header("Location: index.php?c=products&a=index");
    }

    public function edit() {
        global $pdo;
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) die("ID không hợp lệ");

        $repo = new ProductRepository($pdo);
        $product = $repo->findById($id);
        if (!$product) die("Không tìm thấy sản phẩm");

        require "../app/views/products/edit.php";
    }

    public function update() {
        global $pdo;

        $repo = new ProductRepository($pdo);
        $repo->update([
            'id'    => (int)$_POST['id'],
            'name'  => $_POST['name'],
            'sku'   => $_POST['sku'],
            'price' => (float)$_POST['price'],
            'stock' => (int)$_POST['stock']
        ]);

        header("Location: index.php?c=products&a=index");
    }

    public function delete() {
        global $pdo;
        $id = (int)$_POST['id'];
        if ($id <= 0) die("ID không hợp lệ");

        $repo = new ProductRepository($pdo);
        $repo->delete($id);

        header("Location: index.php?c=products&a=index");
    }
}
