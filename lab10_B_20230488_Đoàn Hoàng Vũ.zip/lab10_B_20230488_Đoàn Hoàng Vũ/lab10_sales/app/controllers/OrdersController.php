<?php
require_once __DIR__ . '/../models/OrderRepository.php';
require_once __DIR__ . '/../models/ProductRepository.php';
require_once __DIR__ . '/../models/CustomerRepository.php';

class OrdersController
{
    private $orderRepo;
    private $productRepo;
    private $customerRepo;

    public function __construct()
    {
        $this->orderRepo = new OrderRepository();
        $this->productRepo = new ProductRepository();
        $this->customerRepo = new CustomerRepository();
    }

    public function index()
    {
        $orders = $this->orderRepo->all();
        require __DIR__ . '/../views/orders/index.php';
    }

    public function create()
    {
        $customers = $this->customerRepo->all();
        $products  = $this->productRepo->all();
        require __DIR__ . '/../views/orders/create.php';
    }

    public function store()
    {
        $customer_id = (int)($_POST['customer_id'] ?? 0);
        $items = $_POST['items'] ?? [];

        if ($customer_id <= 0 || empty($items)) {
            die('Dữ liệu không hợp lệ');
        }

        try {
            $orderId = $this->orderRepo->createOrder($customer_id, $items);
            header("Location: index.php?c=orders&a=show&id=" . $orderId);
        } catch (Exception $e) {
            die("Lỗi tạo đơn hàng");
        }
    }

    public function show()
    {
        $id = (int)($_GET['id'] ?? 0);
        if ($id <= 0) die('ID không hợp lệ');

        $order = $this->orderRepo->find($id);
        $items = $this->orderRepo->items($id);

        require __DIR__ . '/../views/orders/show.php';
    }
}
