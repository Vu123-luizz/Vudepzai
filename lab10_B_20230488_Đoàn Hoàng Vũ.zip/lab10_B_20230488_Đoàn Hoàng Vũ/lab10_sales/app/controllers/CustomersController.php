<?php
require_once "../app/models/CustomerRepository.php";

class CustomersController {

    public function index() {
        global $pdo;
        $repo = new CustomerRepository($pdo);
        $customers = $repo->getAll();
        require "../app/views/customers/index.php";
    }

    public function create() {
        require "../app/views/customers/create.php";
    }

    public function store() {
        global $pdo;

        $email = $_POST['email'];
        if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            die("Email không hợp lệ");
        }

        $repo = new CustomerRepository($pdo);
        $repo->insert([
            'full_name' => $_POST['full_name'],
            'email'     => $email,
            'phone'     => $_POST['phone']
        ]);

        header("Location: index.php?c=customers&a=index");
    }
}
