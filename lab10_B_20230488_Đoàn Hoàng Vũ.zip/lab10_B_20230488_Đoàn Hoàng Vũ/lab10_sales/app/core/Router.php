<?php
class Router {
    public function dispatch($controller, $action) {
        $controller = ucfirst($controller) . "Controller";
        $file = "../app/controllers/$controller.php";

        if (!file_exists($file)) die("Controller not found");

        require_once $file;
        $obj = new $controller();

        if (!method_exists($obj, $action)) die("Action not found");

        $obj->$action();
    }
}
