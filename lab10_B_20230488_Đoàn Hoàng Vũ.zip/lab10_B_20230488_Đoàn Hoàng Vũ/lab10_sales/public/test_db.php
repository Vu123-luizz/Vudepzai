<?php
try {
    $pdo = new PDO(
        "mysql:host=localhost;dbname=lab10_sales;charset=utf8mb4",
        "root",
        ""
    );
    echo "KẾT NỐI OK";
} catch (PDOException $e) {
    echo $e->getMessage();
}
