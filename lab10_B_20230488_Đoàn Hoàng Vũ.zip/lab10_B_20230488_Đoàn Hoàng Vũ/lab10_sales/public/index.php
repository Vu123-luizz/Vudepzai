<?php
require_once "../app/config/db.php";
require_once "../app/core/Router.php";

$router = new Router();
$router->dispatch($_GET['c'] ?? 'products', $_GET['a'] ?? 'index');
