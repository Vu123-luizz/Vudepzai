<?php
require_once __DIR__.'/../models/Product.php';

class ProductController {
    private $model;

    public function __construct() {
        $this->model = new Product();
    }

    public function search() {
        $q = $_GET['q'] ?? '';
        echo json_encode([
            'success'=>true,
            'message'=>'OK',
            'data'=>$this->model->search($q)
        ]);
    }

    public function store() {
        $this->model->store($_POST['code'],$_POST['name'],$_POST['price']);
        echo json_encode(['success'=>true,'message'=>'Added','data'=>null]);
    }

    public function update() {
        $ok = $this->model->update(
            $_POST['id'],$_POST['code'],$_POST['name'],$_POST['price']
        );
        echo json_encode(['success'=>$ok,'message'=>'Updated','data'=>null]);
    }

    public function delete() {
        $ok = $this->model->delete($_POST['id']);
        echo json_encode([
            'success'=>$ok,
            'message'=>$ok?'Deleted':'Not found',
            'data'=>null
        ]);
    }
}
