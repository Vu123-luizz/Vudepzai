<?php
require_once __DIR__.'/../config/database.php';

class Product {
    private $conn;

    public function __construct() {
        $this->conn = Database::connect();
    }

    public function search($q) {
        $sql = "SELECT * FROM products
                WHERE name LIKE ? OR code LIKE ?
                ORDER BY id DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute(["%$q%", "%$q%"]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function store($code, $name, $price) {
        $sql = "INSERT INTO products(code,name,price,created_at)
                VALUES (?,?,?,NOW())";
        return $this->conn->prepare($sql)->execute([$code,$name,$price]);
    }

    public function update($id, $code, $name, $price) {
        $sql = "UPDATE products SET code=?, name=?, price=? WHERE id=?";
        return $this->conn->prepare($sql)->execute([$code,$name,$price,$id]);
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM products WHERE id=?");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }
}
