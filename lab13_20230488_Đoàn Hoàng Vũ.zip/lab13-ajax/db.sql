CREATE DATABASE lab13_ajax CHARACTER SET utf8mb4;
USE lab13_ajax;

CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(50),
    name VARCHAR(255),
    price DECIMAL(10,2),
    created_at DATETIME
);

INSERT INTO products(code, name, price, created_at) VALUES
('P01','Keyboard',200000,NOW()),
('P02','Mouse',100000,NOW()),
('P03','Monitor',3000000,NOW()),
('P04','Laptop',15000000,NOW()),
('P05','USB',50000,NOW());
