function load(q = '') {
    $.get('api.php', {
        action: 'search',
        q: q
    }, function (res) {
        if (!res.success) {
            console.error(res.message);
            return;
        }

        let html = '';
        res.data.forEach(p => {
            html += `
            <tr data-id="${p.id}">
                <td>${p.id}</td>
                <td class="code">${p.code}</td>
                <td class="name">${p.name}</td>
                <td class="price">${p.price}</td>
                <td>
                    <button class="edit btn btn-warning btn-sm">Edit</button>
                    <button class="del btn btn-danger btn-sm">Delete</button>
                </td>
            </tr>`;
        });
        $('#list').html(html);
    }, 'json');
}

load();


// LIVE SEARCH
$('#search').on('keyup', function () {
    load($(this).val());
});


// SAVE (ADD / UPDATE)
$('#save').on('click', function () {
    let action = $('#id').val() ? 'update' : 'store';

    $.post('api.php?action=' + action, {
        id: $('#id').val(),
        code: $('#code').val(),
        name: $('#name').val(),
        price: $('#price').val()
    }, function (res) {
        if (res.success) {
            load();
            $('#id,#code,#name,#price').val('');
        } else {
            alert(res.message);
        }
    }, 'json');
});


// EDIT
$(document).on('click', '.edit', function () {
    let tr = $(this).closest('tr');
    $('#id').val(tr.data('id'));
    $('#code').val(tr.find('.code').text());
    $('#name').val(tr.find('.name').text());
    $('#price').val(tr.find('.price').text());
});


// DELETE
$(document).on('click', '.del', function () {
    if (!confirm('Bạn có chắc muốn xóa?')) return;

    let id = $(this).closest('tr').data('id');

    $.post('api.php?action=delete', { id: id }, function (res) {
        if (res.success) {
            load();
        } else {
            alert(res.message);
        }
    }, 'json');
});
