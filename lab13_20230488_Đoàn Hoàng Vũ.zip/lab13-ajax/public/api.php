<?php
header('Content-Type: application/json');
require_once '../app/controllers/ProductController.php';

$action = $_GET['action'] ?? '';

$ctl = new ProductController();

switch ($action) {
    case 'search':
        $ctl->search();
        break;
    case 'store':
        $ctl->store();
        break;
    case 'update':
        $ctl->update();
        break;
    case 'delete':
        $ctl->delete();
        break;
    default:
        echo json_encode([
            'success' => false,
            'message' => 'Invalid API',
            'data' => null
        ]);
}
