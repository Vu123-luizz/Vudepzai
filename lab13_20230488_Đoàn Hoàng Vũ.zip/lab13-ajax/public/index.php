<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Product Manager | Ajax CRUD</title>

<!-- Bootstrap 5 -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Icons -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="assets/js/app.js"></script>

<style>
body { background:#f4f6f9; }
.card { border-radius:16px; }
.table thead { background:#343a40; color:white; }
</style>
</head>

<body>
<div class="container py-4">

    <h2 class="fw-bold mb-4">
        <i class="bi bi-box-seam"></i> Product Management
    </h2>

    <!-- SEARCH -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <input type="text" id="search"
                class="form-control form-control-lg"
                placeholder="🔍 Search by name or code...">
        </div>
    </div>

    <!-- FORM -->
    <div class="card shadow-sm mb-4">
        <div class="card-header fw-semibold">
            <i class="bi bi-pencil-square"></i> Add / Edit Product
        </div>
        <div class="card-body">
            <input type="hidden" id="id">
            <div class="row g-3">
                <div class="col-md-3">
                    <input id="code" class="form-control" placeholder="Product Code">
                </div>
                <div class="col-md-5">
                    <input id="name" class="form-control" placeholder="Product Name">
                </div>
                <div class="col-md-2">
                    <input id="price" class="form-control" placeholder="Price">
                </div>
                <div class="col-md-2 d-grid">
                    <button id="save" class="btn btn-primary">
                        <i class="bi bi-save"></i> Save
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- TABLE -->
    <div class="card shadow-sm">
        <div class="card-header fw-semibold">
            <i class="bi bi-list-ul"></i> Product List
        </div>
        <div class="card-body p-0">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th width="120">Action</th>
                    </tr>
                </thead>
                <tbody id="list"></tbody>
            </table>
        </div>
    </div>

</div>
</body>
</html>
